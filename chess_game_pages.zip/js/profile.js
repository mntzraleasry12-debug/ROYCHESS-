document.addEventListener('DOMContentLoaded',()=>{
 const user=ChessApp.user(); const name=document.querySelector('#profileName');
 name.textContent=user?user.name:'زائر'; document.querySelector('#profileEmail').textContent=user?user.email:'لم تسجل الدخول بعد';
 document.querySelector('#logout').addEventListener('click',()=>{localStorage.removeItem('chessUser');location.href='login.html';});
});
