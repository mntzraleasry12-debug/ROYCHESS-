document.addEventListener('DOMContentLoaded',()=>{
 const stats=ChessApp.get('chessStats',{games:0,wins:0,draws:0,losses:0});
 Object.keys(stats).forEach(k=>{const el=document.querySelector(`[data-stat="${k}"]`);if(el)el.textContent=stats[k];});
});
