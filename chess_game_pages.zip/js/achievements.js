document.addEventListener('DOMContentLoaded',()=>{
 const stats=ChessApp.get('chessStats',{games:0,wins:0});
 const items=[['البداية','أكمل أول مباراة',stats.games>=1],['فوزك الأول','حقق أول انتصار',stats.wins>=1],['عشر مباريات','أكمل 10 مباريات',stats.games>=10]];
 const list=document.querySelector('#achievementList');
 list.innerHTML=items.map(([n,d,ok])=>`<li>${ok?'🏆':'🔒'} <b>${n}</b><br><span class="notice">${d}</span></li>`).join('');
});
