document.addEventListener('DOMContentLoaded',()=>{
 const sound=document.querySelector('#sound'), music=document.querySelector('#music'), theme=document.querySelector('#theme');
 const s=ChessApp.get('chessSettings',{sound:true,music:false,theme:'dark'});
 sound.checked=s.sound; music.checked=s.music; theme.value=s.theme;
 const save=()=>ChessApp.set('chessSettings',{sound:sound.checked,music:music.checked,theme:theme.value});
 [sound,music,theme].forEach(el=>el.addEventListener('change',save));
});
