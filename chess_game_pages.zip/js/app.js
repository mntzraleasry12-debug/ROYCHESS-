// أدوات مشتركة بسيطة بين صفحات اللعبة
const ChessApp = {
  get(key, fallback) { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } },
  set(key, value) { localStorage.setItem(key, JSON.stringify(value)); },
  user() { return this.get('chessUser', null); },
  requireUser() { if (!this.user()) location.href = 'login.html'; }
};
