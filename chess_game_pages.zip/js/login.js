document.addEventListener('DOMContentLoaded',()=>{
 const form=document.querySelector('#loginForm'); if(!form)return;
 form.addEventListener('submit',e=>{e.preventDefault();
 const name=document.querySelector('#name').value.trim();
 const email=document.querySelector('#email').value.trim();
 if(!name||!email){alert('يرجى إدخال الاسم والبريد الإلكتروني');return;}
 ChessApp.set('chessUser',{name,email}); alert('تم حفظ الحساب على هذا الجهاز'); location.href='profile.html';
 });
});
