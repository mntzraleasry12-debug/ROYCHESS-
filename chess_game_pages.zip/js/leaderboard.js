document.addEventListener('DOMContentLoaded',()=>{
 const scores=ChessApp.get('chessLeaderboard',[{name:'لاعب الشطرنج',points:1200},{name:'المناور',points:980},{name:'البطل',points:850}]);
 document.querySelector('#leaders').innerHTML=scores.map((x,i)=>`<li>${i+1}. ${x.name}<span style="float:left;color:var(--gold)">${x.points} نقطة</span></li>`).join('');
});
